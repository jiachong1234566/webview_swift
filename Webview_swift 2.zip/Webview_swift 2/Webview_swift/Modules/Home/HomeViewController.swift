//
//  HomeViewController.swift
//  Webview_swift
//
//  Created by 贾崇 on 2018/9/14.
//  Copyright © 2018年 贾崇. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController,WebViewVCDelegate {
    
    lazy var v1: WebViewController = {
        let v1 = WebViewController(urlPath: "https://www.baidu.com");
        v1.delegate = self;
        return v1;
    }()
    
    lazy var pageView: DNSPageView = {
        // 创建DNSPageStyle，设置样式
        let style = DNSPageStyle()
        style.isTitleScrollEnable = false
        style.isScaleEnable = true
        style.isShowBottomLine = true
        style.titleSelectedColor = UIColor.black
        style.titleColor = UIColor.gray
        style.bottomLineColor = DominantColor
        style.bottomLineHeight = 2
        
        let titles = ["百度"]
        let v5 = WebViewController(urlPath: "https://www.zhihu.com/#signin");
        let viewControllers:[UIViewController] = [self.v1];
        
        for vc in viewControllers{
            self.addChildViewController(vc)
        }
        
        let pageView = DNSPageView(frame: CGRect(x: 0, y: navigationBarHeight, width: ScreenWidth, height: ScreenHeigth-navigationBarHeight-44), style: style, titles: titles, childViewControllers: viewControllers)
        return pageView;
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.view.backgroundColor = UIColor.black;
        self.addNavigationView();
        view.addSubview(self.pageView)
    }
    
    func addNavigationView() -> Void {
        /*
        //中间Title
        let title = UILabel(frame:CGRect(x: 0, y: 0, width: 100, height: 30));
        title.text = "webview";
        //在这改变字体大小样式
        title.font = UIFont.systemFont(ofSize: 18, weight: UIFont.Weight.medium);
        title.textColor = UIColor.blue;
        title.textAlignment = NSTextAlignment.center;
        self.navigationItem.titleView = title;
        */
        
        //左边按钮
        let leftItem = UIBarButtonItem(title: "返回", style: UIBarButtonItemStyle.done, target: self, action: #selector(HomeViewController.leftBtnClick));
        self.navigationItem.leftBarButtonItem = leftItem;
        
        //右边按钮
        let rightItem = UIBarButtonItem(title: "刷新", style: UIBarButtonItemStyle.done, target: self, action: #selector(HomeViewController.rightBtnClick));
        self.navigationItem.rightBarButtonItem = rightItem;
    }
    
    @objc  func leftBtnClick(){
        NSLog("-leftBtnClick 返回--");
        if self.v1.webView.canGoBack {
            self.v1.webView.goBack();
        }
    }
    
    @objc  func rightBtnClick(){
        // 延迟1秒执行
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(1 * NSEC_PER_SEC))/Double(NSEC_PER_SEC) , execute: {
            self.v1.refresh();
            NSLog("-rightBtnClick 刷新--");
        })
    }
    
    // WebViewVCDelegate
    func getWebViewTitle(title: String) {
        self.title = title;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
