//
//  WebViewController.swift
//  Webview_swift
//
//  Created by 贾崇 on 2018/9/14.
//  Copyright © 2018年 贾崇. All rights reserved.
//

import UIKit
import WebKit

protocol WebViewVCDelegate:NSObjectProtocol {
    func getWebViewTitle(title: String);
}

class WebViewController: UIViewController{
    
    var urlPath: String = "";
    var progrssObserver : NSKeyValueObservation?;
    var titleObserver : NSKeyValueObservation?;
    var webViewTitle : String = "";
    weak var delegate : WebViewVCDelegate?;
    
    convenience init(urlPath: String = "") {
        self.init()
        self.urlPath = urlPath;
    }
    
    lazy var webView: WKWebView = {
        let webview = WKWebView.init(frame: CGRect(x:0, y:0, width: ScreenWidth, height:ScreenHeigth-navigationBarHeight-44));
        webview.isOpaque = false;
        webview.backgroundColor = UIColor.black;
        return webview;
    }()
    
    lazy private var progressView: UIProgressView = {
        self.progressView = UIProgressView.init(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: ScreenWidth, height: 2))
        self.progressView.tintColor = UIColor.blue       // 进度条颜色
        self.progressView.trackTintColor = UIColor.white // 进度条背景色
        return self.progressView
    }()

    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl();
        return refreshControl
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.view.backgroundColor = UIColor.black;
        self.view.addSubview(webView);
        self.view.addSubview(self.progressView);
        self.addRefresh();
        
        // kvo progress
        progrssObserver = webView.observe(\.estimatedProgress, options: .new) { [weak self] (_, changed) in
            if let new = changed.newValue {
                self?.changeProgress(Float(new));
            }
        }
        
        // kvo title
        titleObserver = webView.observe(\.title, options: .new) { [weak self] (_, changed) in
            if let new = changed.newValue {
                self?.webViewTitle = (String?(new!))!;
                self?.delegate?.getWebViewTitle(title: (self?.webViewTitle)!);
                NSLog("--%@--", self?.webViewTitle ?? "");
            }
        }
        
        let url = URL(string: urlPath);
        let request = URLRequest (url: url!);
        self.webView.load(request);
    }
    
    func changeProgress(_ progress: Float) {
        self.progressView.alpha = 1.0
        self.progressView.isHidden = progress == 1;
        self.progressView.setProgress(Float(progress), animated: true);
        if progress  >= 1.0 {
            UIView.animate(withDuration: 0.3, delay: 0.1, options: .curveEaseOut, animations: {
                self.progressView.alpha = 0
            }, completion: { (finish) in
                self.progressView.setProgress(0.0, animated: false)
            })
        }
    }

    func addRefresh() {
        self.refreshControl.addTarget(self, action:#selector(WebViewController.refresh), for: .valueChanged)
        self.webView.scrollView.addSubview(refreshControl)
    }
    
    @objc func refresh(){
        self.webView.reload()
        self.refreshControl.endRefreshing()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
